//
//  NewsFeedPresenter.swift
//  NewsFeed
//
//  Created by Александр on 15.01.2021.
//  Copyright (c) 2021 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol NewsFeedPresentationLogic {
  func presentData(response: NewsFeed.Model.Response.ResponseType)
}

class NewsFeedPresenter: NewsFeedPresentationLogic {
  weak var viewController: NewsFeedDisplayLogic?
    
    let dateFormater:DateFormatter = {
        let dt = DateFormatter()
        dt.locale = Locale(identifier: "ru_RU")
        dt.dateFormat = "d MMM 'в' HH:mm"
        return dt
    }()
  
  func presentData(response: NewsFeed.Model.Response.ResponseType) {
  
    switch response {

    case .presentNewsFeed(feed: let feed):
        
        let cells = feed.items.map { (feedItem) in
            CellViewModel(from: feedItem, profiles: feed.profiles, groups: feed.groups)
        }

        
        let feedVieModel = FeedViewModel.init(cells: cells)
        
 
    
        viewController?.displayData(viewModel: NewsFeed.Model.ViewModel.ViewModelData.displayNewsFeed(feed: feedVieModel ))
    }
    
    
  }
    
    private func CellViewModel(from feedItem: FeedItem,profiles:[Profile],groups:[Group])-> FeedViewModel.Cell {
        
        let profile = self.profile(from: feedItem.sourceId, profiles: profiles, gpoups: groups)
        
        let photoAttachement = self.photoAttachement(feedItem: feedItem)
        
        let date = Date(timeIntervalSince1970: feedItem.date)
        let dateTitle = dateFormater.string(from: date )
        
        return FeedViewModel.Cell.init(name: profile.name,
                                       date:  dateTitle,
                                       text: feedItem.text,
                                       like: String(feedItem.likes?.count ?? 0 ),
                                       comments: String(feedItem.comments?.count ?? 0 ),
                                       shares: String(feedItem.reposts?.count ?? 0 ),
                                       views: String(feedItem.views?.count ?? 0 ),
                                       iconUrlString: profile.photo,
                                       photoAttachement: photoAttachement )
    }
  
    private func profile(from sourseId: Int, profiles:[Profile],gpoups:[Group])->ProfileRepresentable  {
         
        let profilesOrGroups: [ProfileRepresentable] = sourseId >= 0 ? profiles : gpoups
        let normalSourseId = sourseId >= 0 ? sourseId : -sourseId
        let profileRepresentable = profilesOrGroups.first { (myprofileRepresentable ) -> Bool in
            myprofileRepresentable.id == normalSourseId
        }
        return profileRepresentable!
    }
    
    
    private func photoAttachement (feedItem: FeedItem) -> FeedViewModel.FeedCellPhotoAttachment? {
        guard let photos = feedItem.attachments?.compactMap({ (attachement) in
            attachement.photo
        }), let firstPhoto = photos.first else { return nil  }
        return FeedViewModel.FeedCellPhotoAttachment.init(photoUrlString: firstPhoto.srcBIG, width: firstPhoto.width, height: firstPhoto.height)
    }
    
    
    
}
