//
//  NewsFeedRouter.swift
//  NewsFeed
//
//  Created by Александр on 15.01.2021.
//  Copyright (c) 2021 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol NewsFeedRoutingLogic {

}

class NewsFeedRouter: NSObject, NewsFeedRoutingLogic {

  weak var viewController: NewsFeedViewController?
  
  // MARK: Routing
  
}
